# imageaug-package

This module is used for image augmentation. Currently wrapped imagaug library from aleju.

# Installation
```
pip install git+ssh://git@github.com/darwinharianto/imageaug-package.git

# or clone locally
git clone https://github.com/darwinharianto/imageaug-package.git
pip install -e .
```

# Usage
usage sample can be seen at test.py
